<?php

namespace Illuminate\Support\Testing\Fakes;

interface Fake
{
    //
}
